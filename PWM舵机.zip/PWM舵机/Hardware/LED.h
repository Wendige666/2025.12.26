#ifndef __LED_H
#define __LED_H

void LED_Init(void);
void LED1_NO(void);
void LED1_OFF(void);
void LED2_NO(void);
void LED2_OFF(void);
void LED1_Turn(void);
void LED2_Turn(void);

#endif
