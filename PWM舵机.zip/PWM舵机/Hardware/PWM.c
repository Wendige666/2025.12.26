#include "stm32f10x.h"
#include "PWM.h"

/**
 * @brief  TIM2_CH2 -> PA1  PWM初始化
 * @note   50Hz (20ms周期), 脉宽范围 500~2500μs
 */
void PWM_Init(void)
{
    // 1. 开启时钟
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

    // 2. PA1 复用推挽输出 (TIM2_CH2)
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_1;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    // 3. TIM2 内部时钟
    TIM_InternalClockConfig(TIM2);

    // 4. 时基配置：72MHz / 72 = 1MHz (1us计数)
    //    ARR = 20000-1 → 20ms → 50Hz (舵机标准频率)
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
    TIM_TimeBaseInitStructure.TIM_ClockDivision     = TIM_CKD_DIV1;
    TIM_TimeBaseInitStructure.TIM_CounterMode       = TIM_CounterMode_Up;
    TIM_TimeBaseInitStructure.TIM_Period            = 20000 - 1;  // 20ms
    TIM_TimeBaseInitStructure.TIM_Prescaler         = 72 - 1;     // 1us
    TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseInitStructure);

    // 5. PWM 通道2 配置
    TIM_OCInitTypeDef TIM_OCInitStructure;
    TIM_OCStructInit(&TIM_OCInitStructure);
    TIM_OCInitStructure.TIM_OCMode      = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OCPolarity  = TIM_OCPolarity_High;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse       = 1500;  // 初始中位 90°
    TIM_OC2Init(TIM2, &TIM_OCInitStructure);

    // 6. 启动定时器
    TIM_Cmd(TIM2, ENABLE);
}

/**
 * @brief  直接设置PWM脉宽
 * @param  Compare: 脉宽值 (单位: μs, 范围 500~2500)
 */
void PWM_SetCompare2(uint16_t Compare)
{
    // 限幅保护（MG996R 安全范围）
    if(Compare < 500)  Compare = 500;
    if(Compare > 2500) Compare = 2500;
    
    TIM_SetCompare2(TIM2, Compare);
}
