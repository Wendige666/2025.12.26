#ifndef __COUNTSENSOR_H
#define __COUNTSENSOR_H

void CTSR_Init(void);
uint16_t CountSensor(void);

#endif