#ifndef __BUZZER_H
#define __BUZZER_H

void Buzzer_Init(void);
void Buzzer_NO(void);
void Buzzer_OFF(void);
void Buzzer_Turn(void);

#endif

