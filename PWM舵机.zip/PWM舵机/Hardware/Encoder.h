#ifndef __ENCODER_H
#define __ENCODER_H

int16_t ER_Get(void);
void ER_Init(void);
#endif





