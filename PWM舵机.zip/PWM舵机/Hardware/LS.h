#ifndef __LS_H
#define __LS_H

void LS_Init(void);
uint8_t LS_Get(void);

#endif

