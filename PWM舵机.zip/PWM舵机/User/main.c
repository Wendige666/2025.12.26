#include "stm32f10x.h"
#include "Delay.h"
#include "OLED.H"
#include "KeyPro.h"
#include "Servo.h"
#include "Serial.h"
#include <string.h>   
#include <stdlib.h>   
#include <math.h> 

uint16_t Kum;
uint8_t action_active = 2;

/* ---------- �Ӿ��������� ---------- */
float BallPos = 0.0f;
float LastBallPos = 0.0f;
float BallSpeed = 0.0f;
float TargetPos = 0.0f;
float Error = 0.0f;

/* ---------- ������� ---------- */
float BaseAngle = 90.0f;
float ServoAngle = 90.0f;
float Kp = 2.8f;           // ? ��΢��С����ֹ��
float Kd = 1.2f;           // ? ������΢��ϵ�����ٶ����ᣩ

/* ---------- �ٶȷ�ƽ��� ---------- */
float SpeedThreshold = 12.0f;
float FlatReturnSpeed = 1.0f;
uint8_t FlatMode = 0;
uint16_t FlatCounter = 0;
uint8_t NewDataReceived = 0;

/* ---------- ? ������״̬����أ������� ---------- */
typedef enum {
    T3_IDLE = 0,        // ����
    T3_RUN_PLUS,        // ����ȥ +5cm
    T3_HOLD_PLUS,       // �ȶ��� +5cm
    T3_RUN_MINUS,       // ����ȥ -5cm
    T3_HOLD_MINUS,      // �ȶ��� -5cm
    T3_SUCCESS          // �ɹ����
} Test3_State;

Test3_State t3_state = T3_IDLE;
uint32_t t3_timer = 0;         // ״̬�ڲ���ʱ����ms��
uint32_t t3_total_timer = 0;   // �ܺ�ʱ��ms��
uint8_t Test3_Enable = 0;      // ������ʹ�ܱ�־

/* ---------- ������� ---------- */
#define SERVO_INCREASE  0
#define SERVO_DECREASE  1
#define SERVO_STOP      2
uint8_t Servo_Direction = SERVO_STOP;

uint16_t int_array[10] = {0};
int n,i;

/* ==================== �������� ==================== */
void Servo_Control_By_Comparison(float current_pos, float target_pos);
void Update_OLED_Display(void);
void Calc_Speed(void);
void Flat_Process(void);
void Test3_Process(void);  // ? ������������״̬����������

/* ==================== ������ ==================== */
int main(void)
{
    OLED_Init();
    Servo_Init();
    Serial_Init();
    KeyPro_Init();

    int window = 1, choose = 1;
    uint8_t k = 0;
    uint8_t first_run = 1;

    OLED_ShowString(1, 1, "Ball:");
    OLED_ShowString(2, 1, "Tar:");
    OLED_ShowString(3, 1, "Err:");
    OLED_ShowString(4, 1, "Ang:");
    OLED_ShowString(4, 10, "STP");

    Servo_SetAngle(BaseAngle);
    Delay_ms(500);

    while(1)
    {
        Kum = key[0].long_flag;

        /* ---------- �˵��߼�����ȫ��������չ�� ---------- */
        if(action_active == 2)
        {
            if(key[0].long_flag && k == 0)
            {
                key[0].long_flag = 0;
                Kum = 0;
                if(choose == 1 && window == 1)
                {
                    window = 2;
                    choose = 3;
                    OLED_ShowString(1, 3, "           ");
                    OLED_ShowString(2, 3, "           ");
                    OLED_ShowString(1, 3, "  Level 1");
                    OLED_ShowString(2, 3, "  Level 2");
                    OLED_ShowString(3, 3, "  Level 3");
                    OLED_ShowString(4, 3, "  Level 4");  // ? ���� Level 4
                    Delay_ms(50);
                    Kum = 0;
                }
                else if(choose == 2 && window == 1)
                {
                    window = 3;
                    choose = 3;
                    OLED_ShowString(1, 3, "           ");
                    OLED_ShowString(2, 3, "           ");
                    OLED_ShowString(1, 3, "  Level 1");
                    OLED_ShowString(2, 3, "  Level 2");
                    OLED_ShowString(3, 3, "  Level 3");
                    Delay_ms(50);
                    Kum = 0;
                }

                if(choose == 1 && window == 2)
                {
                    key[0].long_flag = 0;
                    OLED_ShowString(1, 3, "           ");
                    OLED_ShowString(2, 3, "           ");
                    OLED_ShowString(3, 3, "           ");
                    TargetPos = 5.0f;
                    Delay_ms(50);
                    Kum = 0;
                }
                // ??? ������Level 4 ���������� ???
                else if(choose == 3 && window == 2)
                {
                    key[0].long_flag = 0;
                    OLED_ShowString(1, 3, "           ");
                    OLED_ShowString(2, 3, "           ");
                    OLED_ShowString(3, 3, "           ");
                    OLED_ShowString(4, 3, "           ");
                    
                    // ����������
                    Test3_Enable = 1;
                    t3_state = T3_IDLE;
                    t3_timer = 0;
                    t3_total_timer = 0;
                    
                    OLED_ShowString(4, 1, "TEST3 ON");
                    Delay_ms(500);
                    Kum = 0;
                }
            }

            if(key[0].short_flag)
            {
                if(window == 1)
                {
                    if(choose == 1)
                    {
                        choose = 2;
                        OLED_ShowString(2, 12, "<");
                        OLED_ShowString(1, 12, " ");
                    }
                    else if(choose == 2)
                    {
                        choose = 1;
                        OLED_ShowString(1, 12, "<");
                        OLED_ShowString(2, 12, " ");
                    }
                }
                else if(window == 2 || window == 3)
                {
                    k++;
                    if(choose == 1)
                    {
                        choose = 2;
                        OLED_ShowString(2, 12, "<");
                        OLED_ShowString(1, 12, " ");
                    }
                    else if(choose == 2)
                    {
                        choose = 3;
                        OLED_ShowString(3, 12, "<");
                        OLED_ShowString(2, 12, " ");
                    }
                    else if(choose == 3)
                    {
                        choose = 4;  // ? �������л��� Level 4
                        OLED_ShowString(4, 12, "<");
                        OLED_ShowString(3, 12, " ");
                    }
                    else if(choose == 4)  // ? ������ѭ���� Level 1
                    {
                        choose = 1;
                        OLED_ShowString(1, 12, "<");
                        OLED_ShowString(4, 12, " ");
                    }
                }
                Delay_ms(20);
                key[0].short_flag = 0;
            }
            OLED_ShowNum(1, 15, choose, 1);
            OLED_ShowNum(1, 14, window, 1);
        }

        /* ---------- ���ڽ��գ��޸���֧��С�������� ---------- */
        if(Serial_GetRxFlag() == 1)
        {
            char str_buffer[20];
            int i;
            for(i = 0; i < 19 && Serial_RxPacket[i] != 0; i++)
                str_buffer[i] = (char)(Serial_RxPacket[i] & 0xFF);
            str_buffer[i] = '\0';

            // ? �޸������� $+05.5# ��ʽ������
            if(str_buffer[0] == '$' && str_buffer[i-1] == '#')
            {
                str_buffer[i-1] = '\0';      // ȥ�� '#'
                char *num_str = &str_buffer[1]; // ָ�� "+05.5"
                
                if(!first_run)
                    LastBallPos = BallPos;
                else
                    first_run = 0;

                BallPos = atof(num_str);  // ? ʹ�� atof ����������
                
                // �޷� ��12.5cm���ڸ˳���25cm��
                if(BallPos > 12.5f) BallPos = 12.5f;
                if(BallPos < -12.5f) BallPos = -12.5f;

                OLED_ShowString(4, 1, "            ");
                OLED_ShowString(4, 1, num_str);
                
                NewDataReceived = 1;
            }
        }

        /* ---------- �ٶȼ��� ---------- */
        Calc_Speed();

        /* ---------- ? ������״̬���������� ---------- */
        Test3_Process();

        /* ---------- ��ƽ���������ģ� ---------- */
        // ע�⣺����������ʱ��ʱ���÷�ƽ���������
        if(!Test3_Enable)
        {
            Flat_Process();
        }

        /* ---------- ������� ---------- */
        if(Test3_Enable)
        {
            // ������ģʽ��ʹ��PD����
            Servo_Control_By_Comparison(BallPos, TargetPos);
        }
        else
        {
            // ԭ�����߼�
            if(!FlatMode)
            {
                Servo_Control_By_Comparison(BallPos, TargetPos);
            }
            else
            {
                Servo_Direction = SERVO_STOP;
            }
        }

        /* ---------- ��ʾ ---------- */
        Update_OLED_Display();
        OLED_ShowString(3, 10, "Sp:");
        OLED_ShowSignedNum(3, 13, (int)BallSpeed, 3);

        if(Test3_Enable)
        {
            // ������ģʽ����ʾ״̬
            // ״̬��ʾ�Ѿ��� Test3_Process �д�����
        }
        else if(FlatMode)
            OLED_ShowString(4, 10, "FLT");
        else
            OLED_ShowString(4, 10, "RUN");

        Delay_ms(50);
    }
}

/* ==================== �������� ==================== */

/**
 * @brief ����С���ٶ�
 */
void Calc_Speed(void)
{
    static uint8_t first = 1;
    if(first || !NewDataReceived)
    {
        BallSpeed = 0;
        first = 0;
        return;
    }

    BallSpeed = (BallPos - LastBallPos) / 0.05f;
    NewDataReceived = 0;
}

/**
 * @brief �ٶȷ�ƽ��˿���棩
 */
void Flat_Process(void)
{
    static float target_angle = 90.0f;

    if(!FlatMode)
    {
        if(fabs(BallSpeed) > SpeedThreshold)
        {
            FlatMode = 1;
            FlatCounter = 0;
            target_angle = ServoAngle;
            OLED_ShowString(4, 10, "FLT");
        }
    }
    else
    {
        FlatCounter++;

        // ˿�����У�ָ��˥��
        target_angle += (BaseAngle - target_angle) * 0.15f;

        ServoAngle = target_angle;
        Servo_SetAngle(ServoAngle);

        // �˳�����
        if(FlatCounter >= 6)
        {
            if((fabs(ServoAngle - BaseAngle) < 1.0f) &&
               (fabs(BallSpeed) < (SpeedThreshold * 0.5f)))
            {
                FlatMode = 0;
                FlatCounter = 0;
            }
            else if(FlatCounter > 20)   // ��ʱ����
            {
                FlatMode = 0;
                FlatCounter = 0;
            }
        }
    }
}

/**
 * @brief ? ������״̬����������
 */
void Test3_Process(void)
{
    if(Test3_Enable == 0) return;
    
    t3_total_timer += 50;  // ÿ50ms�ۼ�
    
    switch(t3_state)
    {
        case T3_IDLE:
            TargetPos = 0.0f;
            OLED_ShowString(4, 1, "T3:IDLE ");
            // С�������ĸ����Ҿ�ֹ����ʼ����
            if(fabs(BallPos) < 1.0f && fabs(BallSpeed) < 2.0f)
            {
                t3_state = T3_RUN_PLUS;
                t3_timer = 0;
            }
            break;
            
        case T3_RUN_PLUS:
            TargetPos = 5.0f;
            t3_timer += 50;
            OLED_ShowString(4, 1, "T3:+5cm  ");
            // �����ж���λ�����<0.8cm �� �ٶ�<3cm/s
            if(fabs(BallPos - 5.0f) < 0.8f && fabs(BallSpeed) < 3.0f)
            {
                t3_state = T3_HOLD_PLUS;
                t3_timer = 0;
            }
            // ��ʱ�������������3�룩
            if(t3_timer > 3000) t3_state = T3_SUCCESS;
            break;
            
        case T3_HOLD_PLUS:
            TargetPos = 5.0f;
            t3_timer += 50;
            OLED_ShowString(4, 1, "T3:HOLD+");
            // �ȶ�0.5��
            if(t3_timer > 500) 
            {
                t3_state = T3_RUN_MINUS;
                t3_timer = 0;
            }
            break;
            
        case T3_RUN_MINUS:
            TargetPos = -5.0f;
            t3_timer += 50;
            OLED_ShowString(4, 1, "T3:-5cm  ");
            if(fabs(BallPos + 5.0f) < 0.8f && fabs(BallSpeed) < 3.0f)
            {
                t3_state = T3_HOLD_MINUS;
                t3_timer = 0;
            }
            if(t3_timer > 3000) t3_state = T3_SUCCESS;
            break;
            
        case T3_HOLD_MINUS:
            TargetPos = -5.0f;
            t3_timer += 50;
            OLED_ShowString(4, 1, "T3:HOLD-");
            if(t3_timer > 500) 
            {
                t3_state = T3_SUCCESS;
            }
            break;
            
        case T3_SUCCESS:
            TargetPos = -5.0f;  // ����ͣ��-5cm
            OLED_ShowString(4, 1, "T3: OK! ");
            // ��ʾ�ܺ�ʱ���룩
            OLED_ShowNum(4, 10, t3_total_timer/1000, 2);
            break;
    }
}

/**
 * @brief PIDλ�ÿ��ƣ�? �޸�ΪPD���ƣ�
 */
void Servo_Control_By_Comparison(float current_pos, float target_pos)
{
    Error = target_pos - current_pos;

    // ����
    if(fabs(Error) < 0.3f)
    {
        Servo_Direction = SERVO_STOP;
        ServoAngle = BaseAngle;
        goto SET_SERVO;
    }

    // ??? PD���ƺ��ģ�P�� + D��ٶ����ᣩ???
    // D��ʹ�ø���С���ٶȣ����������ã���ֹ���ͷ
    float output = Kp * Error - Kd * BallSpeed;
    
    ServoAngle = BaseAngle + output;

    // ��λ
    if(ServoAngle < 0)   ServoAngle = 0;
    if(ServoAngle > 180) ServoAngle = 180;

SET_SERVO:
    Servo_SetAngle(ServoAngle);
}

/**
 * @brief OLED��ʾ
 */
void Update_OLED_Display(void)
{
    // ��ʾС��λ�ã���һλС����
    int pos_int = (int)fabs(BallPos);
    int pos_dec = (int)(fabs(BallPos) * 10) % 10;
    OLED_ShowChar(1, 6, BallPos >= 0 ? '+' : '-');
    OLED_ShowNum(1, 7, pos_int, 2);
    OLED_ShowChar(1, 9, '.');
    OLED_ShowNum(1, 10, pos_dec, 1);
    
    // ��ʾĿ��λ��
    int tar_int = (int)fabs(TargetPos);
    int tar_dec = (int)(fabs(TargetPos) * 10) % 10;
    OLED_ShowChar(2, 6, TargetPos >= 0 ? '+' : '-');
    OLED_ShowNum(2, 7, tar_int, 2);
    OLED_ShowChar(2, 9, '.');
    OLED_ShowNum(2, 10, tar_dec, 1);
    
    // ��ʾ���
    int err_int = (int)fabs(Error);
    int err_dec = (int)(fabs(Error) * 10) % 10;
    OLED_ShowChar(3, 6, Error >= 0 ? '+' : '-');
    OLED_ShowNum(3, 7, err_int, 2);
    OLED_ShowChar(3, 9, '.');
    OLED_ShowNum(3, 10, err_dec, 1);
    
    // ��ʾ����Ƕ�
    OLED_ShowNum(4, 6, (int)ServoAngle, 3);

    switch(Servo_Direction)
    {
        case SERVO_INCREASE: OLED_ShowString(4, 10, "INC"); break;
        case SERVO_DECREASE: OLED_ShowString(4, 10, "DEC"); break;
        default: OLED_ShowString(4, 10, "STP"); break;
    }
}
