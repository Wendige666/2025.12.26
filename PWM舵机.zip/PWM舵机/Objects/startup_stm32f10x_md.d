.\objects\startup_stm32f10x_md.o: start\1\startup_stm32f10x_md.s
