//#include "KeyPro.h"
//#include "OLED.h"
//#include "stm32f10x.h"                  // Device header
//#include "stm32f10x_gpio.h"

//void KeyPro_Init(void)
//{

//  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE); 
//	
//	GPIO_InitTypeDef GPIO_InitStructure;
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
//	GPIO_InitStructure.GPIO_Pin  = GPIO_Pin_10|GPIO_Pin_1;
//	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
//	GPIO_Init(GPIOB,&GPIO_InitStructure);
//}

//struct keys key[4]={0,0,0,0};

//void Key_Scan(void)//中断回调函数
//{
// 
//		  key[0].key_sta = GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_10);
//		  key[1].key_sta = GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_1);
////	  	key[2].key_sta = GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_2);
////		  key[3].key_sta = GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_0);
//		
//	  for(uint8_t i=0;i<2;i++)
//		{
//			switch(key[i].judge_sta)
//		  {
//				case 0:
//				{
//					if(key[i].key_sta == 1)
//					{				
//						key[i].judge_sta = 1;
//						key[i].key_time = 0;
//					}
//				}
//				break;
//				case 1:
//				{
//					if(key[i].key_sta == 1)
//					{
//						key[i].judge_sta = 2;
//					}
//					else
//					{
//						key[i].judge_sta = 0;
//					}
//				}
//				break;
//				case 2:
//				{
//					if(key[i].key_sta == 0)
//					{
//						key[i].judge_sta = 0;
//						if(key[i].key_time<100)
//						{
//							key[i].short_flag = 1;
//						}
//					}
//					else
//					{
//						key[i].key_time ++;
//						if(key[i].key_time>100)
//						{
//							key[i].long_flag = 1;
//						}
//					}
//				}
//			  break;
//			}
//		}	
//	}

#include "KeyPro.h"
#include "stm32f10x.h"
#include "stm32f10x_gpio.h"
#include "stm32f10x_tim.h"
#include "stm32f10x_rcc.h"

struct keys key[4] = {0, 0, 0, 0};

/**
  * @brief  按键初始化函数
  * @retval None
  */
void KeyPro_Init(void)
{
    // 使能GPIO时钟
    RCC_APB2PeriphClockCmd(/*RCC_APB2Periph_GPIOA |*/ RCC_APB2Periph_GPIOB, ENABLE);
    
    GPIO_InitTypeDef GPIO_InitStructure;
    
    // 配置GPIO为输入上拉模式
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);

    /* 2. 关闭 JTAG，保留 SWD（不影响下载调试） */
    GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);

    /* 3. 原来的代码 */
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    
    // 初始化GPIOB的按键引脚 (PB0, PB1, PB2)
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3| GPIO_Pin_4| GPIO_Pin_5;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
    
    // 初始化GPIOA的按键引脚 (PA0)
   // GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
   // GPIO_Init(GPIOA, &GPIO_InitStructure);
    
    // 初始化定时器2用于按键扫描
    TIM2_Init();
}

/**
  * @brief  定时器2初始化
  * @retval None
  */
void TIM2_Init(void)
{
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    
    // 使能TIM2时钟
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
    
    // 定时器基础配置 - 1ms中断
    TIM_TimeBaseStructure.TIM_Period = 1000 - 1;        // 自动重装载值
    TIM_TimeBaseStructure.TIM_Prescaler = 720 - 1;       // 预分频器，72MHz/72 = 1MHz
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
    
    // 使能更新中断
    TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);
    
    // 配置NVIC
    NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
    
    // 使能定时器
    TIM_Cmd(TIM2, ENABLE);
}

/**
  * @brief  定时器2中断处理函数
  * @retval None
  */
void TIM2_IRQHandler(void)
{
    if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
    {
        TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
        
        // 读取按键状态 - 标准库函数
        key[0].key_sta = GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_3);
        key[1].key_sta = GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_4);
        key[2].key_sta = GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_5);
      //  key[3].key_sta = GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_3);
        
        for(uint8_t i = 0; i < 4; i++)
        {
            switch(key[i].judge_sta)
            {
                case 0:  // 等待按键按下
                    if(key[i].key_sta == 0)  // 按键按下（低电平）
                    {
                        key[i].judge_sta = 1;
                        key[i].key_time = 0;
                    }
                    break;
                    
                case 1:  // 按键消抖确认
                    if(key[i].key_sta == 0)  // 仍然按下
                    {
                        key[i].judge_sta = 2;
                    }
                    else  // 已释放，认为是抖动
                    {
                        key[i].judge_sta = 0;
                    }
                    break;
                    
                case 2:  // 检测按键释放或长按
                    if(key[i].key_sta == 1)  // 按键释放
                    {
                        key[i].judge_sta = 0;
                        if(key[i].key_time < 100)  // 短按（100ms）
                        {
                            key[i].short_flag = 1;
                        }
                    }
                    else  // 按键仍然按下
                    {
                        key[i].key_time++;
                        if(key[i].key_time > 100)  // 长按（100ms）
                        {
                            key[i].long_flag = 1;
                        }
                    }
                    break;
            }
        }
    }
}
