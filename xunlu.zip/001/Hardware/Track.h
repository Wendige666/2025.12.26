#ifndef __TRACK_H
#define __TRACK_H
#include "stm32f10x.h"

/* 传感器输出极性：低电平有效 = 1（常见 DO 口 OC 输出）；高电平有效改成 0 */
#ifndef TRACK_ACTIVE_LOW
#define TRACK_ACTIVE_LOW    1
#endif

#define TRACK_NUM           6           /* 6 路 */
#define TRACK_MASK          0x3F        /* bit0~bit5 有效 */

void    Track_Init(void);
uint8_t Track_Read(void);               /* bit0~bit5，1 = 检测到信号（已按极性归一化） */
uint8_t Track_GetCount(void);           /* 当前有几路命中 */
int8_t  Track_GetError(void);           /* 位置偏差 -5~+5；返回 0x7F = 全部脱线 */


#endif
