#include "stm32f10x.h"
#include "Track.h"

/* ===== 引脚映射：从左到右 S1~S6，换引脚只改这张表 ===== */
#define TRACK_GPIO_PORT     GPIOD
#define TRACK_GPIO_CLK      RCC_APB2Periph_GPIOD

static const uint16_t Track_Pin[TRACK_NUM] = {
    GPIO_Pin_8,     /* S1 最左 */
    GPIO_Pin_9,     /* S2 */
    GPIO_Pin_12,    /* S3 */
    GPIO_Pin_13,    /* S4 */
    GPIO_Pin_14,    /* S5 */
    GPIO_Pin_15     /* S6 最右 */
};

/* 加权表：越靠边权重绝对值越大，配合 PID 用 */
static const int8_t Track_Weight[TRACK_NUM] = { -5, -3, -1, 1, 3, 5 };

void Track_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;        /* C89：声明必须在最前面 */
    uint8_t i;

    RCC_APB2PeriphClockCmd(TRACK_GPIO_CLK, ENABLE);

#if TRACK_ACTIVE_LOW
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;   /* 低电平有效 -> 上拉，空闲为高 */
#else
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;   /* 高电平有效 -> 下拉，空闲为低 */
#endif
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

    for (i = 0; i < TRACK_NUM; i++)
    {
        GPIO_InitStructure.GPIO_Pin = Track_Pin[i];
        GPIO_Init(TRACK_GPIO_PORT, &GPIO_InitStructure);
    }
}

uint8_t Track_Read(void)
{
    uint8_t i;
    uint8_t val = 0;

    /* 先按物理电平组装，bit0~bit5 一一对应 S1~S6 */
    for (i = 0; i < TRACK_NUM; i++)
    {
        if (GPIO_ReadInputDataBit(TRACK_GPIO_PORT, Track_Pin[i]) != Bit_RESET)
        {
            val |= (uint8_t)(1u << i);          /* 物理高电平 -> 置 1 */
        }
    }

#if TRACK_ACTIVE_LOW
    val = (uint8_t)((~val) & TRACK_MASK);       /* 低电平有效：取反，1 = 收到信号 */
#else
    val = (uint8_t)(val & TRACK_MASK);
#endif

    return val;
}

static uint8_t Track_ReadHit(void)
{
    return (uint8_t)((~Track_Read()) & TRACK_MASK);   /* TRACK_MASK 即 0x3F（6路） */
}

uint8_t Track_GetCount(void)
{
    uint8_t i;
    uint8_t val;
    uint8_t cnt = 0;

    val = Track_ReadHit();   /* 原为 val = Track_Read(); */
    for (i = 0; i < TRACK_NUM; i++)
    {
        if (val & (uint8_t)(1u << i))
        {
            cnt++;
        }
    }
    return cnt;
}

int8_t Track_GetError(void)
{
    uint8_t i;
    uint8_t val;
    uint8_t cnt = 0;
    int16_t sum = 0;

    val = Track_ReadHit();   /* 原为 val = Track_Read(); */
    if (val == 0)
    {
        return 0x7F;                            /* 全都没信号：脱线/冲出赛道 */
    }

    for (i = 0; i < TRACK_NUM; i++)
    {
        if (val & (uint8_t)(1u << i))
        {
            sum += Track_Weight[i];
            cnt++;
        }
    }

    return (int8_t)(sum / cnt);                 /* 多路灯同时命中时取平均，-5~+5 */
}


