#ifndef __NMOTOR_H
#define __NMOTOR_H

void NMotor_Init(void);
void NMotor_SetPWM(int16_t PWM);

#endif
