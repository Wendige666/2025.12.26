#include "stm32f10x.h"                  // Device header
#include "NPWM.h"

void NMotor_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2 | GPIO_Pin_3;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
	
	NPWM_Init();
}

void NMotor_SetPWM(int16_t PWM)
{
	if (PWM >= 0)
	{
		GPIO_SetBits(GPIOD, GPIO_Pin_2);
		GPIO_ResetBits(GPIOD, GPIO_Pin_3);
		NPWM_SetCompare1(PWM);
	}
	else
	{
		GPIO_ResetBits(GPIOD, GPIO_Pin_2);
		GPIO_SetBits(GPIOD, GPIO_Pin_3);
		NPWM_SetCompare1(-PWM);
	}
}
