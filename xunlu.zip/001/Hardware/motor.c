#include "stm32f10x.h"                  // Device header
              
#include "PWM.h"

void Motor_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);
	
	GPIO_InitTypeDef GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4 | GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOD, &GPIO_InitStructure);
	
	PWM_Init();
}

void Motor_SetPWM(int16_t PWM)
{
	if (PWM >= 0)
	{
		GPIO_SetBits(GPIOD, GPIO_Pin_5);
		GPIO_ResetBits(GPIOD, GPIO_Pin_4);
		PWM_SetCompare2(PWM);
	}
	else
	{
		GPIO_ResetBits(GPIOD, GPIO_Pin_5);
		GPIO_SetBits(GPIOD, GPIO_Pin_4);
		PWM_SetCompare2(-PWM);
	}
}
