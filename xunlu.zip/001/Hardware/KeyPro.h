//#ifndef __KEYPRO_H
//#define __KEYPRO_H

//#include "stm32f10x.h"                  // Device header
//#include <stdint.h>
//void TIM2_IRQHandler(void);
//struct keys
//{
//	uint8_t key_sta;
//	uint8_t judge_sta;
//	uint8_t short_flag;
//	uint8_t long_flag;
//	uint8_t key_time;
//};
//extern struct keys key[4];
//#endif

#ifndef __KEYPRO_H
#define __KEYPRO_H

#include "stm32f10x.h"

struct keys {
    uint8_t key_sta;
    uint8_t judge_sta;
    uint8_t short_flag;
    uint8_t long_flag;
    uint32_t key_time;
};

extern struct keys key[4];

// 函数声明
void KeyPro_Init(void);
void TIM2_Init(void);

#endif /* __KEYPRO_H */
