#ifndef __ENCODER_SOFT_H
#define __ENCODER_SOFT_H

#include "stm32f10x.h"

void Encoder_Soft_Init(void);
int16_t Encoder2_Get(void); 

#endif
