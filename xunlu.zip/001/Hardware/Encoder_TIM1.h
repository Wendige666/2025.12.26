#ifndef __ENCODER_TIM1_H
#define __ENCODER_TIM1_H

#include "stm32f10x.h"

void Encoder_TIM1_Init(void);
int16_t Encoder1_Get(void); 

#endif
