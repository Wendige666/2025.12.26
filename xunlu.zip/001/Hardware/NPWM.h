#ifndef __NPWM_H
#define __NPWM_H

void NPWM_Init(void);
void NPWM_SetCompare1(uint16_t Compare);

#endif
