#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "Track.h"

#include "KeyPro.h"
#include "TIMER_BASE.h"
#include "OLED.h"
#include "Encoder_TIM1.h"
#include "Encoder_Soft.h"
#include "Motor.h"
#include "NMotor.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <math.h>

#define EPSILON 0.0001

uint8_t KeyNum;
volatile uint8_t  GO    = 0;  
volatile uint32_t timeB = 0; 
uint32_t A=0;
int32_t BV;    //偏向值

float LTarget,LActual,LOut;
float LKp=0.4 , LKi=0.15 , LKd=0.0 ;
float LError0,LError1,LErrorInt;
float RTarget,RActual,ROut;
float RKp=0.4 , RKi=0.15 , RKd=0.0 ; 
float RError0,RError1,RErrorInt;

/* ===== 循迹  差速 参数 ===== */
#define BASE_SPEED      80.0f  
#define STEER_K         5.0f   
#define SPEED_MAX       100.0f
#define SPEED_MIN       -25.0f 
#define SMOOTH          0.25f  

int8_t  TrackErr = 0;
int8_t  LastErr  = 0;
float   LTargetCmd = 0.0f, RTargetCmd = 0.0f;

//uint32_t Track_ToDec(uint8_t mask)
//{
//    uint32_t dec = 0;
//    int8_t   i;

//    for (i = 5; i >= 0; i--)
//    {
//        dec = dec * 10 + ((mask >> i) & 1);
//    }
//    return dec;
//}

static void Run_Start(uint32_t ms)
{
    LastErr = 0;
    LTargetCmd = RTargetCmd = 0.0f;
    LTarget    = RTarget    = 0.0f;
    LError0 = LError1 = LErrorInt = 0.0f; 
    RError0 = RError1 = RErrorInt = 0.0f;
    timeB = ms;
    GO    = 1;
}

static void Run_Stop(void)
{
    GO = 0;
    timeB = 0;
    LTargetCmd = RTargetCmd = 0.0f;
    LTarget    = RTarget    = 0.0f;
}

int main(void)
{
	OLED_Init();
	Track_Init();
	Motor_Init();
	NMotor_Init();
	KeyPro_Init();
	
	Encoder_TIM1_Init();   // PA8-9 → M1
    Encoder_Soft_Init();   // PA10-11 → M2
	Timer6_Init();
		
	while(1)
	{
		KeyNum = key[2].long_flag;
  
		if(key[2].short_flag)
		{
		Run_Start(23200);
		key[2].short_flag=0;
		} 
		if(KeyNum==1)
		{
		key[2].long_flag=0;
		Run_Start(5000);
		}
		
		while(GO)
		{
			TrackErr = Track_GetError();	
			if (TrackErr == 0x7F) 
			{
			TrackErr = LastErr;
			LTargetCmd = BASE_SPEED * 0.6f - (float)LastErr * STEER_K * 1.5f;
			RTargetCmd = BASE_SPEED * 0.6f + (float)LastErr * STEER_K * 1.5f;
			} 
			else 
			{
			LastErr = TrackErr;
			LTargetCmd = BASE_SPEED - (float)TrackErr * STEER_K;
			RTargetCmd = BASE_SPEED + (float)TrackErr * STEER_K;
			}

			LTarget += (LTargetCmd - LTarget) * SMOOTH;
			RTarget += (RTargetCmd - RTarget) * SMOOTH;

			/* ---------- 4. OLED ---------- */
			OLED_ShowBinNum(0, 0, (~Track_Read()) & 0x3F, 6, OLED_8X16);  /* 翻回1=压线，直观 */
			OLED_Printf(64, 0, OLED_8X16, "E:%+03d", TrackErr);           /* 看误差 */
			OLED_Printf(64,16, OLED_8X16, "Tar:%+04.0f", RTarget);
			OLED_Printf(64,32, OLED_8X16, "Act:%+04.0f", RActual);
			OLED_Printf(64,48, OLED_8X16, "Out:%+04.0f", ROut);
			OLED_Printf(0,16, OLED_8X16, "Tar:%+04.0f", LTarget);
			OLED_Printf(0,32, OLED_8X16, "Act:%+04.0f", LActual);
			OLED_Printf(0,48, OLED_8X16, "Out:%+04.0f", LOut);
			OLED_Update();
		}
		 Run_Stop(); 
	}
}


void TIM6_IRQHandler(void)
{
	static uint16_t Count1,Count2;
    if (TIM_GetITStatus(TIM6, TIM_IT_Update) == SET)
    {
		if (GO)                                  /* ★ 只在运行时倒数 */
		{
			if (timeB > 0) timeB--;
			if (timeB == 0) GO = 0;
		}

		if (!GO)                                 /* ★ 停止时强制断电 + 清积分 */
		{
			LErrorInt = RErrorInt = 0.0f;
			LOut = ROut = 0.0f;
			Motor_SetPWM(0);
			NMotor_SetPWM(0);
		}		
		else if (++Count1 >= 40)
		{
			Count1=0;			
			
			LActual = Encoder2_Get();
			
			LError1 = LError0;
			LError0 = LTarget - LActual;
			
			if(fabs(LKi) > EPSILON)
			{
				LErrorInt += LError0;
			}
			else
			{
				LErrorInt = 0;
			}
			
			LOut = LKp * LError0 + LKi * LErrorInt + LKd * (LError0 - LError1);
			
			if(LOut >  100){LOut =  100;}
			if(LOut < -100){LOut = -100;}
			if (LErrorInt >  500) LErrorInt =  500;
			if (LErrorInt < -500) LErrorInt = -500;
			
			NMotor_SetPWM(LOut);
			
			RActual = Encoder1_Get();
			
			RError1 = RError0;
			RError0 = RTarget - RActual;
			
			if(fabs(RKi) > EPSILON)
			{
				RErrorInt += RError0;
			}
			else
			{
				RErrorInt = 0;
			}
			
			ROut = RKp * RError0 + RKi * RErrorInt + RKd * (RError0 - RError1);
			
			if(ROut >  100){ROut =  100;}
			if(ROut < -100){ROut = -100;}
			if (RErrorInt >  500) RErrorInt =  500;
			if (RErrorInt < -500) RErrorInt = -500;
			
			Motor_SetPWM(ROut);
		}
		
//		Count2++;
//		if (Count2>=40)
//		{

//			
//			Motor_SetPWM(ROut);
//		}
		
        TIM_ClearITPendingBit(TIM6, TIM_IT_Update);
    }
}
