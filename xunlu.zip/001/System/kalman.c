#include "kalman.h"

/**
 * @brief  初始化卡尔曼滤波器
 * @param  kalman: 滤波器结构体指针
 */
void Kalman_Init(Kalman_t *kalman)
{
    // 默认参数（绝大多数场景不用改，震动大再微调）
    kalman->Q_angle = 0.001f;    // 角度过程噪声，越小越相信陀螺仪
    kalman->Q_bias  = 0.003f;    // 零偏过程噪声，越小越相信零偏不变
    kalman->R_measure = 0.03f;   // 观测噪声，越大越不相信加速度计
    
    kalman->angle = 0.0f;
    kalman->bias = 0.0f;
    kalman->rate = 0.0f;
    
    // 初始化误差协方差矩阵
    kalman->P[0][0] = 1.0f;
    kalman->P[0][1] = 0.0f;
    kalman->P[1][0] = 0.0f;
    kalman->P[1][1] = 1.0f;
}

/**
 * @brief  卡尔曼滤波更新
 * @param  kalman: 滤波器结构体指针
 * @param  new_angle: 加速度计计算的观测角度（°）
 * @param  new_rate: 陀螺仪测量的角速度（°/s，已减零偏）
 * @param  dt: 采样时间间隔（s，必须和实际采样周期一致）
 * @retval 融合后的估计角度（°）
 */
float Kalman_Update(Kalman_t *kalman, float new_angle, float new_rate, float dt)
{
    // -------------------- 1. 预测步（先验估计）--------------------
    // 角度预测：θ = θ_prev + (ω - b) * dt
    kalman->rate = new_rate - kalman->bias;
    kalman->angle += kalman->rate * dt;
    
    // 误差协方差预测
    kalman->P[0][0] += dt * (dt * kalman->P[1][1] - kalman->P[0][1] - kalman->P[1][0] + kalman->Q_angle);
    kalman->P[0][1] -= dt * kalman->P[1][1];
    kalman->P[1][0] -= dt * kalman->P[1][1];
    kalman->P[1][1] += kalman->Q_bias * dt;
    
    // -------------------- 2. 更新步（后验估计）--------------------
    // 计算卡尔曼增益
    float S = kalman->P[0][0] + kalman->R_measure;  // 创新协方差
    float K[2];  // 卡尔曼增益
    K[0] = kalman->P[0][0] / S;
    K[1] = kalman->P[1][0] / S;
    
    // 创新（观测值 - 预测值）
    float y = new_angle - kalman->angle;
    
    // 更新状态和协方差
    kalman->angle += K[0] * y;
    kalman->bias  += K[1] * y;
    
    float P00_temp = kalman->P[0][0];
    float P01_temp = kalman->P[0][1];
    kalman->P[0][0] -= K[0] * P00_temp;
    kalman->P[0][1] -= K[0] * P01_temp;
    kalman->P[1][0] -= K[1] * P00_temp;
    kalman->P[1][1] -= K[1] * P01_temp;
    
    return kalman->angle;
}
