#ifndef __TIMER_BASE_H
#define __TIMER_BASE_H

#include "stm32f10x.h"

void Timer6_Init (void);

#endif
