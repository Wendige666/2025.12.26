#ifndef __KALMAN_H
#define __KALMAN_H

#include "stm32f10x.h"

// 单轴卡尔曼滤波器结构体（Roll/Pitch各用一个）
typedef struct {
    float Q_angle;    // 角度过程噪声协方差（默认0.001）
    float Q_bias;     // 零偏过程噪声协方差（默认0.003）
    float R_measure;  // 观测噪声协方差（默认0.03）
    
    float angle;      // 估计的角度（°）
    float bias;       // 估计的陀螺仪零偏（°/s）
    float rate;       // 去除零偏后的角速度（°/s）
    
    float P[2][2];    // 误差协方差矩阵
} Kalman_t;

// 函数声明
void Kalman_Init(Kalman_t *kalman);
float Kalman_Update(Kalman_t *kalman, float new_angle, float new_rate, float dt);

#endif
